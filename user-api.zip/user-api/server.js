const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;


app.use(bodyParser.json());
app.use(cors({
    origin: '*', // Specify allowed origin
    methods: ['GET', 'POST'], // Specify allowed HTTP methods
    allowedHeaders: ['Content-Type', 'Authorization'], // Specify allowed headers
  }));
let users = [
    { id: 1, name: 'John Doe', email: 'john@example.com' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
  ];
  

// Add a new user
app.post('/users', (req, res) => {
  try {
    const { username, email } = req.body;
    const newUser = { id: Date.now(), username, email };
    users.push(newUser);
    res.status(201).json(newUser);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update an existing user
app.post('/users/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { username, email } = req.body;
    const index = users.findIndex(user => user.id === parseInt(id));
    if (index === -1) {
      return res.status(404).json({ message: 'Uer not found' });
    }
    users[index].name = username;
    users[index].email = email;
    res.json(users[index]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/users', (req, res) => {
  try {
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(() => {
  console.log(`Server is running on port ${PORT}`);
});
 